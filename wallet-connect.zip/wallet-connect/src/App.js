import React, { useState } from 'react';
import './App.css';
import { useWalletConnect } from '@provenanceio/walletconnect-js';

function App() {

  const { walletConnectService, walletConnectState } = useWalletConnect();
  const [connecting, setConnecting] = useState(false);
  const handleConnect = async () => {
    setConnecting(true);
    await walletConnectService.connect()
    setConnecting(false);
  };

  const handleDisconnect = () => {
    walletConnectService.disconnect();
  };

  console.log(walletConnectState)
  return (
    <div>
      {walletConnectState.status === 'connected' ? (
        <>
          <div>Wallet Address: {walletConnectState.address}</div>
          <button onClick={handleDisconnect}>Disconnect</button>
        </>
      ) : (
        <>
          {connecting ? (
            <div>Connecting...</div>
          ) : (
            <button onClick={handleConnect}>Connect</button>
          )}
        </>
      )}
    </div>
  );
}

export default App;
